create definer = root@localhost trigger RENTS_INSERT
    after insert
    on rents
    for each row
BEGIN
    INSERT INTO RENTS_AUD (EVENT_DATE, EVENT_TYPE, RENT_ID, NEW_BOOK_ID, NEW_READER_ID,
                           NEW_RENT_DATE, NEW_RETURN_DATE)
        VALUE(CURTIME(), "INSERT", NEW.RENT_ID, NEW.BOOK_ID, NEW.READER_ID, NEW.RENT_DATE,
              NEW.RETURN_DATE);
END;

