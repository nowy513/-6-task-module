create
    definer = root@localhost function ListBooks(id_user int) returns varchar(20)
BEGIN
    DECLARE result VARCHAR(20) DEFAULT 'Incorrect BOOK_ID';
    IF id_user <= 0 THEN
        SET result = 'Incorrect BOOK_ID';
        return result;
#     ELSE
#         SELECT READER_ID FIRSTNAME, LASTNAME FROM READERS;
    END IF;
END;

