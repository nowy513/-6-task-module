create definer = root@localhost trigger READERS_DELETE
    after delete
    on readers
    for each row
BEGIN
    INSERT INTO READERS_AUD (EVENT_DATE, EVENT_TYPE, READER_ID)
        VALUE(CURTIME(), "DELETE", OLD.READER_ID);
END;

