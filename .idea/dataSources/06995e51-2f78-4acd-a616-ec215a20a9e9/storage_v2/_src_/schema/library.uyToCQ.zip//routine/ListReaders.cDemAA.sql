create
    definer = root@localhost procedure ListReaders(IN readers_id int)
BEGIN
    DECLARE result varchar(20) DEFAULT 'Incorrect Reader ID';
    IF readers_id <= 0 THEN
        SELECT result;
        ELSE
    SELECT READER_ID, FIRSTNAME, LASTNAME FROM READERS WHERE READER_ID = readers_id;
    END IF ;
END;

