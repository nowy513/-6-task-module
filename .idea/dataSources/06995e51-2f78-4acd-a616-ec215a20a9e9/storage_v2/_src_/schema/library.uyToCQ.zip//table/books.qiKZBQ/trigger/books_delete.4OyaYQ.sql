create definer = root@localhost trigger BOOKS_DELETE
    after delete
    on books
    for each row
BEGIN
    INSERT INTO BOOKS_AUD (EVENT_DATE, EVENT_TYPE, BOOK_ID)
        VALUE(CURTIME(), "DELETE", OLD.BOOK_ID);
END;

